const temperatureSlider = document.getElementById("temperature-slider");
const temperatureDisplay = document.getElementById("temperature-display");

temperatureSlider.addEventListener("input", () => {
  temperatureDisplay.innerHTML = temperatureSlider.value + "&deg;C";
});

const notifications = document.getElementById("notifications");
const notificationsDisplay = document.getElementById("notifications-display");

notifications.addEventListener("change", () => {
  notificationsDisplay.innerHTML = "Notifications: " + notifications.options[notifications.selectedIndex].text;
});

const lightingMode = document.getElementById("lighting-mode");
const lightingModeDisplay = document.getElementById("lighting-mode-display");

lightingMode.addEventListener("change", () => {
  lightingModeDisplay.innerHTML = "Lighting Mode: " + lightingMode.options[lightingMode.selectedIndex].text;
});

const submitBtn = document.getElementById("submit-btn");
const errorMessage = document.getElementById("error-message");

submitBtn.addEventListener("click", function() {
  const postalCode = document.getElementById("Postal_code").value.trim();
  const regex = /^[A-Za-z]\d[A-Za-z]\s?\d[A-Za-z]\d$/;
 
  
  if (!regex.test(postalCode)) {
    document.getElementById("error-message").style.display = "block";
    return false;
  }
  return true;
});
const datetime = document.getElementById("datetime");

function updateDateTime() {
  const now = new Date() ;
  datetime.innerHTML = now.toLocaleString();
}

updateDateTime();
setInterval(updateDateTime, 1000); 


