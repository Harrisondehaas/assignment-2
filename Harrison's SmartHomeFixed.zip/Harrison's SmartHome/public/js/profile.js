const passwordInput = document.getElementById("password");
const confirmInput = document.getElementById("confirm");
const submitButton = document.getElementById("submit-btn");

submitButton.addEventListener("click", () => {
  if (passwordInput.value !== confirmInput.value) {
    alert("Passwords do not match!");
  }
});