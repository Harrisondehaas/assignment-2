const express = require("express");
const app = express();
const port = 3000;

app.use(express.static("public"));

app.get("/", (req, res) => {
  res.sendFile(__dirname + "/ASSIGNMENT.html");
});
app.get("/ASSIGNMENT.html", (req, res) => {
  res.sendFile(__dirname + "/ASSIGNMENT.html");
});
app.get("/profile.html", (req, res) => {
  res.sendFile(__dirname + "/profile.html");
});

app.listen(port, () => console.info("Listening on port" + port));
